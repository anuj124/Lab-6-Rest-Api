package com.greatlearning.studentManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManagementSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentManagementSecurityApplication.class, args);
	}

}
